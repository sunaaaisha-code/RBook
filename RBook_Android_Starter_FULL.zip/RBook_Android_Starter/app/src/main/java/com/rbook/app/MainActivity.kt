package com.rbook.app

import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import okhttp3.*
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private lateinit var name: EditText
    private lateinit var email: EditText
    private lateinit var password: EditText
    private lateinit var status: TextView

    // IMPORTANT: put only an UNSIGNED upload preset here.
    // Never put your Cloudinary API secret in the Android app.
    private val cloudName = "YOUR_CLOUD_NAME"
    private val uploadPreset = "YOUR_UNSIGNED_UPLOAD_PRESET"

    private val picker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) uploadToCloudinary(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        name = findViewById(R.id.name)
        email = findViewById(R.id.email)
        password = findViewById(R.id.password)
        status = findViewById(R.id.status)

        findViewById<Button>(R.id.register).setOnClickListener { register() }
        findViewById<Button>(R.id.login).setOnClickListener { login() }
        findViewById<Button>(R.id.photo).setOnClickListener {
            if (auth.currentUser == null) {
                toast("Please log in first")
            } else {
                picker.launch("image/*")
            }
        }

        auth.currentUser?.let {
            status.text = "Logged in: ${it.email}"
        }
    }

    private fun register() {
        val n = name.text.toString().trim()
        val e = email.text.toString().trim()
        val p = password.text.toString()

        if (n.isEmpty() || e.isEmpty() || p.length < 6) {
            toast("Enter name, valid email and password (6+ characters)")
            return
        }

        auth.createUserWithEmailAndPassword(e, p)
            .addOnSuccessListener { result ->
                val uid = result.user!!.uid
                val user = mapOf(
                    "uid" to uid,
                    "name" to n,
                    "email" to e,
                    "photoUrl" to "",
                    "bio" to "",
                    "createdAt" to System.currentTimeMillis()
                )
                db.collection("users").document(uid).set(user)
                    .addOnSuccessListener {
                        status.text = "Account created: $e"
                        toast("Registration successful")
                    }
                    .addOnFailureListener { toast(it.message ?: "Firestore error") }
            }
            .addOnFailureListener { toast(it.message ?: "Registration failed") }
    }

    private fun login() {
        val e = email.text.toString().trim()
        val p = password.text.toString()

        auth.signInWithEmailAndPassword(e, p)
            .addOnSuccessListener {
                status.text = "Logged in: $e"
                toast("Login successful")
            }
            .addOnFailureListener { toast(it.message ?: "Login failed") }
    }

    private fun uploadToCloudinary(uri: Uri) {
        if (cloudName.startsWith("YOUR_") || uploadPreset.startsWith("YOUR_")) {
            toast("First set Cloudinary cloud name and unsigned upload preset")
            return
        }

        status.text = "Uploading photo..."

        val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: run {
                toast("Could not read photo")
                return
            }

        val body = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart(
                "file", "rbook_${System.currentTimeMillis()}.jpg",
                bytes.toRequestBody("image/*".toMediaType())
            )
            .addFormDataPart("upload_preset", uploadPreset)
            .build()

        val request = Request.Builder()
            .url("https://api.cloudinary.com/v1_1/$cloudName/image/upload")
            .post(body)
            .build()

        OkHttpClient().newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread { toast("Upload failed: ${e.message}") }
            }

            override fun onResponse(call: Call, response: Response) {
                val text = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    runOnUiThread { toast("Cloudinary error") }
                    return
                }

                val secureUrl = Regex("\"secure_url\"\\s*:\\s*\"([^\"]+)\"")
                    .find(text)?.groupValues?.getOrNull(1)

                if (secureUrl == null) {
                    runOnUiThread { toast("No image URL returned") }
                    return
                }

                val uid = auth.currentUser!!.uid
                val post = mapOf(
                    "uid" to uid,
                    "type" to "image",
                    "mediaUrl" to secureUrl,
                    "caption" to "",
                    "createdAt" to System.currentTimeMillis()
                )

                db.collection("posts").add(post)
                    .addOnSuccessListener {
                        runOnUiThread {
                            status.text = "Photo uploaded and saved"
                            toast("Photo uploaded")
                        }
                    }
                    .addOnFailureListener {
                        runOnUiThread { toast("Photo uploaded, but Firestore save failed") }
                    }
            }
        })
    }

    private fun toast(s: String) =
        Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
