# RBook Android Starter

This is a real Android project starter for:
- Register / Login with Firebase Authentication
- User profile document in Firestore
- Photo upload to Cloudinary
- Photo URL saved in Firestore as a post
- Firestore structure prepared for posts and chat

Before building:
1. Add `app/google-services.json`.
2. Enable Email/Password auth in Firebase.
3. Create Firestore.
4. Create an unsigned Cloudinary upload preset.
5. Set cloudName and uploadPreset in MainActivity.kt.
6. Open the project in Android Studio and Sync/Build.

The current screen is intentionally simple so the backend can be tested first. The next UI layer can add Home feed, Create Post, Profile, Search, Notifications and 1-to-1 Chat.
