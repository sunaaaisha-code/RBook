# RBook Firestore structure

users/{uid}
  uid: string
  name: string
  email: string
  photoUrl: string
  bio: string
  createdAt: number

posts/{postId}
  uid: string
  type: "image" | "video" | "text"
  mediaUrl: string
  caption: string
  createdAt: number

chats/{chatId}
  members: [uid1, uid2]
  lastMessage: string
  updatedAt: number

chats/{chatId}/messages/{messageId}
  senderId: string
  text: string
  mediaUrl: string
  type: "text" | "image" | "video"
  createdAt: number
