# Firebase setup

1. Create a Firebase project.
2. Add an Android app with package name: `com.rbook.app`
3. Enable Authentication > Sign-in method > Email/Password.
4. Create Firestore Database.
5. Download `google-services.json`.
6. Put it here:
   `app/google-services.json`
7. Deploy `firestore.rules` to Firestore.

Collections used:
- users/{uid}
- posts/{postId}
- chats/{chatId}
- chats/{chatId}/messages/{messageId}
