# Cloudinary setup

Use Cloudinary only for media files. Firebase/Firestore stores the URLs and metadata.

1. Open Cloudinary Console.
2. Find your Cloud name.
3. Go to Settings > Upload presets.
4. Create an UNSIGNED upload preset.
5. Put the cloud name and unsigned preset into MainActivity.kt.

Example:
private val cloudName = "my-cloud"
private val uploadPreset = "rbook_unsigned"

NEVER put your Cloudinary API Secret in an Android app.
