# RBook Android Starter

This is a starter Android project for RBook.

## Before building
1. Create a Firebase Android project.
2. Download `google-services.json`.
3. Put it inside `app/`.
4. Enable Firebase Email/Password Authentication.
5. Create Firestore.
6. Set an unsigned Cloudinary upload preset and cloud name in `MainActivity.kt`.

Never put a Cloudinary API secret in the Android app.

## Main features
- Email/password registration
- Email/password login
- Image picker
- Cloudinary image upload
- Firestore post record
